# Stick Hero by Sujay


Bridge-building game heavily inspired by Stick Hero with JavaScript and Canvas.

If you want to know how this game was made, check out this video, that goes through the main ideas: 
[https://youtu.be/eue3UdFvwPo]

Follow me on [discord](#thegod7436)

I have no assotiation with the original game, but if you are interested you can contact me for more.