# shooter_clicker_with_bg.py
# 2D click shooter using Pygame
# - Uses a background image (provided at /mnt/data/8745190.jpg)
# - Ammo is reduced after level 5 and reduced further after level 10
# - Targets < bullets (offset 1..3)
# - Targets preferentially spawn near tree zones (configurable)

import pygame
import random
import sys
import os
from pygame import Vector2

# ---------------------------
# Config
# ---------------------------
SCREEN_WIDTH = 900
SCREEN_HEIGHT = 600
FPS = 60

STARTING_HEALTH = 100
DAMAGE_ON_DESPAWN = 10

# Timing / difficulty
BASE_SPAWN_INTERVAL_MS = 900   # base milliseconds between spawns
SPAWN_INTERVAL_DECREASE_PER_LEVEL = 60
MIN_SPAWN_INTERVAL_MS = 250

BASE_TARGET_LIFESPAN_MS = 1600
LIFESPAN_DECREASE_PER_LEVEL = 100
MIN_LIFESPAN_MS = 500

# Ammo / targets
AMMO_PER_LEVEL = 10   # baseline bullets per level
ENEMY_AMMO_DIFF_MIN = 1
ENEMY_AMMO_DIFF_MAX = 3

# Visuals
TARGET_MIN_RADIUS = 18
TARGET_MAX_RADIUS = 36
CROSSHAIR_RADIUS = 14

FONT_NAME = None  # default font
IMAGE_PATH = "D:\SUJAYGITGAMES\Shooter\8745190.jpg"
# Spawn near trees config
# Define rectangular zones (x,y,w,h) where tree trunks are located in the background image.
# These coordinates are tuned for a 900x600 game window. Adjust if you change screen size or image.
TREE_ZONES = [
    pygame.Rect(40, 120, 140, 380),   # left cluster
    pygame.Rect(180, 140, 140, 360),  # left-middle
    pygame.Rect(340, 100, 180, 420),  # center cluster
    pygame.Rect(540, 120, 180, 360),  # right-middle
    pygame.Rect(700, 150, 140, 340),  # right cluster
]
# Probability that a spawn will pick a tree zone vs anywhere
SPAWN_NEAR_TREE_PROB = 0.8
# Toggle to draw the zones for tuning (set True to debug)
DEBUG_SHOW_TREE_ZONES = False

# ---------------------------
# Game classes
# ---------------------------
class Target:
    def __init__(self, pos, radius, spawn_time_ms, lifespan_ms):
        self.pos = Vector2(pos)
        self.radius = radius
        self.spawn_time_ms = spawn_time_ms
        self.lifespan_ms = lifespan_ms
        self.alive = True

    def is_expired(self, current_time_ms):
        return (current_time_ms - self.spawn_time_ms) >= self.lifespan_ms

    def draw(self, surf):
        # Draw target with rings like a target board
        pygame.draw.circle(surf, (200, 30, 30), (int(self.pos.x), int(self.pos.y)), self.radius)  # outer
        pygame.draw.circle(surf, (240, 240, 240), (int(self.pos.x), int(self.pos.y)), int(self.radius*0.66))
        pygame.draw.circle(surf, (200, 30, 30), (int(self.pos.x), int(self.pos.y)), int(self.radius*0.33))
        # center dot
        pygame.draw.circle(surf, (20, 20, 20), (int(self.pos.x), int(self.pos.y)), max(2, int(self.radius*0.08)))

    def hit_test(self, point):
        return (point - self.pos).length() <= self.radius

# ---------------------------
# Utility functions
# ---------------------------
def current_millis():
    return pygame.time.get_ticks()

# draw ammo icons (small rectangles) for visual ammo display
def draw_ammo_icons(surface, x, y, ammo, max_ammo):
    w = 10
    h = 18
    gap = 6
    for i in range(max_ammo):
        rect = pygame.Rect(x + i*(w + gap), y, w, h)
        if i < ammo:
            # filled bullet icon
            pygame.draw.rect(surface, (220, 200, 60), rect, border_radius=3)
            # small tip
            tip = pygame.Rect(rect.right - 3, rect.y + 3, 3, rect.h - 6)
            pygame.draw.rect(surface, (170, 140, 30), tip, border_radius=2)
        else:
            # empty slot
            pygame.draw.rect(surface, (80, 80, 80), rect, 2, border_radius=3)

# determine ammo for a given level (reductions after lvl 5 and lvl 10)
def ammo_for_level(level):
    # baseline
    ammo = AMMO_PER_LEVEL
    # small reduction after level 5
    if level > 5:
        # reduce a bit but keep a sane minimum
        ammo = max(6, AMMO_PER_LEVEL - 2)
    # bigger reduction after level 10 (cumulative effect)
    if level > 10:
        ammo = max(4, AMMO_PER_LEVEL - 5)
    return ammo

# Helper: pick a spawn point (prefers tree zones if available)
def pick_spawn_point():
    # spawn near a tree zone most of the time (configurable)
    if TREE_ZONES and random.random() < SPAWN_NEAR_TREE_PROB:
        zone = random.choice(TREE_ZONES)
        pad = 20
        x = random.randint(max(zone.left + pad, 60), min(zone.right - pad, SCREEN_WIDTH - 60))
        y = random.randint(max(zone.top + pad, 60), min(zone.bottom - pad, SCREEN_HEIGHT - 60))
        return x, y
    # fallback: anywhere on screen within safe margins
    return random.randint(60, SCREEN_WIDTH - 60), random.randint(60, SCREEN_HEIGHT - 60)

# ---------------------------
# Main Game
# ---------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Click Shooter — Target Practice (BGed)")
    clock = pygame.time.Clock()
    font = pygame.font.Font(FONT_NAME, 22)
    big_font = pygame.font.Font(FONT_NAME, 48)

    # Try load background image
    bg_image = None
    if os.path.exists(IMAGE_PATH):
        try:
            bg_image = pygame.image.load(IMAGE_PATH).convert()
            bg_image = pygame.transform.smoothscale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except Exception as e:
            print("Failed to load background image:", e)
            bg_image = None

    # Game state
    running = True
    game_over = False
    score = 0
    health = STARTING_HEALTH
    level = 1

    # Level-specific state
    enemies_to_spawn = 0
    spawned_count = 0
    active_targets = []
    last_spawn_time = current_millis()
    spawn_interval = BASE_SPAWN_INTERVAL_MS
    target_lifespan = BASE_TARGET_LIFESPAN_MS
    ammo = AMMO_PER_LEVEL
    max_ammo = AMMO_PER_LEVEL

    # start a level: pick enemies_to_spawn to be slightly less than the ammo (diff 1..3)
    def start_level(new_level):
        nonlocal level, enemies_to_spawn, spawned_count, active_targets
        nonlocal last_spawn_time, spawn_interval, target_lifespan, ammo, max_ammo
        level = new_level
        ammo = ammo_for_level(level)
        max_ammo = ammo
        # choose small offset so targets < bullets (difference 1..3)
        offset = random.randint(ENEMY_AMMO_DIFF_MIN, ENEMY_AMMO_DIFF_MAX)
        enemies_to_spawn = max(1, ammo - offset)
        # difficulty adjustments
        spawned_count = 0
        active_targets = []
        last_spawn_time = current_millis()
        spawn_interval = max(BASE_SPAWN_INTERVAL_MS - (level-1) * SPAWN_INTERVAL_DECREASE_PER_LEVEL, MIN_SPAWN_INTERVAL_MS)
        target_lifespan = max(BASE_TARGET_LIFESPAN_MS - (level-1) * LIFESPAN_DECREASE_PER_LEVEL, MIN_LIFESPAN_MS)

    start_level(1)

    while running:
        dt = clock.tick(FPS)
        now = current_millis()

        # -----------------------
        # Events
        # -----------------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_r and not game_over:
                    # restart current level & reset health/score if you want (keeps score)
                    start_level(level)
                    health = STARTING_HEALTH
                    score = 0
                    game_over = False

                if event.key == pygame.K_SPACE and game_over:
                    # Restart whole game
                    score = 0
                    health = STARTING_HEALTH
                    start_level(1)
                    game_over = False

            if event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                if event.button == 1:  # left click - shoot
                    if ammo > 0:
                        ammo -= 1
                        mouse_pos = Vector2(pygame.mouse.get_pos())
                        for t in active_targets[:]:
                            if t.hit_test(mouse_pos):
                                active_targets.remove(t)
                                score += 1
                                break
                    else:
                        # no ammo
                        pass

        # -----------------------
        # Spawn logic (if still have to spawn)
        # -----------------------
        if spawned_count < enemies_to_spawn and (now - last_spawn_time) >= spawn_interval:
            spawn_x, spawn_y = pick_spawn_point()
            radius = random.randint(TARGET_MIN_RADIUS, TARGET_MAX_RADIUS)
            t = Target((spawn_x, spawn_y), radius, now, target_lifespan)
            active_targets.append(t)
            spawned_count += 1
            last_spawn_time = now

        # -----------------------
        # Update targets: check despawn
        # -----------------------
        for t in active_targets[:]:
            if t.is_expired(now):
                active_targets.remove(t)
                health -= DAMAGE_ON_DESPAWN
                if health < 0:
                    health = 0

        # -----------------------
        # Level completion
        # -----------------------
        if spawned_count >= enemies_to_spawn and len(active_targets) == 0 and not game_over:
            # level cleared -> next level
            next_level = level + 1
            start_level(next_level)

        # -----------------------
        # Check game over
        # -----------------------
        if health <= 0:
            game_over = True

        # -----------------------
        # Drawing
        # -----------------------
        # Draw background image if available, else fallback color
        if bg_image:
            screen.blit(bg_image, (0,0))
            # subtle dark overlay so HUD is readable
            overlay = pygame.Surface((SCREEN_WIDTH, 60), pygame.SRCALPHA)
            overlay.fill((10, 10, 10, 120))
            screen.blit(overlay, (0,0))
        else:
            screen.fill((30, 30, 40))  # background

        # If debugging, draw the tree zones so you can tune them
        if DEBUG_SHOW_TREE_ZONES:
            for z in TREE_ZONES:
                s = pygame.Surface((z.width, z.height), pygame.SRCALPHA)
                s.fill((40, 200, 40, 50))
                screen.blit(s, (z.left, z.top))
                pygame.draw.rect(screen, (40,200,40), z, 2)

        # Draw targets
        for t in active_targets:
            t.draw(screen)

        # Draw HUD
        score_surf = font.render(f"Score: {score}", True, (230, 230, 230))
        level_surf = font.render(f"Level: {level}", True, (230, 230, 230))
        screen.blit(score_surf, (12, 8))
        screen.blit(level_surf, (12, 36))

        # Ammo text + icons
        ammo_text_surf = font.render(f"Ammo:", True, (230, 230, 230))
        ammo_x = SCREEN_WIDTH - 220
        ammo_y = 8
        screen.blit(ammo_text_surf, (ammo_x, ammo_y))
        icons_x = ammo_x + ammo_text_surf.get_width() + 12
        icons_y = ammo_y
        draw_ammo_icons(screen, icons_x, icons_y, ammo, max_ammo)

        # Health bar
        hb_x, hb_y, hb_w, hb_h = (SCREEN_WIDTH//2 - 160, 12, 320, 22)
        pygame.draw.rect(screen, (60,60,60), (hb_x, hb_y, hb_w, hb_h), border_radius=6)
        health_ratio = max(0, health) / STARTING_HEALTH
        inner_w = int((hb_w - 4) * health_ratio)
        inner_rect = pygame.Rect(hb_x + 2, hb_y + 2, inner_w, hb_h - 4)
        pygame.draw.rect(screen, (200, 50, 50), inner_rect, border_radius=6)
        h_surf = font.render(f"HP: {health}", True, (230,230,230))
        screen.blit(h_surf, (SCREEN_WIDTH//2 - 30, hb_y + 24))

        # Enemies remaining this level counter:
        rem = max(0, enemies_to_spawn - spawned_count + len(active_targets))
        rem_surf = font.render(f"Targets Remaining: {rem}", True, (230,230,230))
        screen.blit(rem_surf, (12, SCREEN_HEIGHT - 30))

        # Draw crosshair (follow mouse)
        mx, my = pygame.mouse.get_pos()
        pygame.draw.line(screen, (240, 240, 240), (mx - CROSSHAIR_RADIUS, my), (mx + CROSSHAIR_RADIUS, my), 2)
        pygame.draw.line(screen, (240, 240, 240), (mx, my - CROSSHAIR_RADIUS), (mx, my + CROSSHAIR_RADIUS), 2)
        pygame.draw.circle(screen, (240,240,240), (mx, my), 4, 2)

        # If no ammo show a message
        if ammo <= 0 and not game_over:
            no_ammo_surf = font.render("OUT OF AMMO — wait for next level (or press R to restart level)", True, (240, 200, 60))
            screen.blit(no_ammo_surf, (SCREEN_WIDTH//2 - no_ammo_surf.get_width()//2, SCREEN_HEIGHT - 60))

        # Game over overlay
        if game_over:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((10, 10, 10, 180))
            screen.blit(overlay, (0,0))
            go_surf = big_font.render("GAME OVER", True, (240, 80, 80))
            sub_surf = font.render(f"Final score: {score} — Press SPACE to restart", True, (235,235,235))
            screen.blit(go_surf, (SCREEN_WIDTH//2 - go_surf.get_width()//2, SCREEN_HEIGHT//2 - 60))
            screen.blit(sub_surf, (SCREEN_WIDTH//2 - sub_surf.get_width()//2, SCREEN_HEIGHT//2 + 10))

        # Flip
        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
